﻿using System;
using System.Windows.Forms;

namespace Veterinaria
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Veterinaria.Views.LoginForm());
        }
    }
}
