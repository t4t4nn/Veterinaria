﻿CREATE DATABASE Veterinaria;
GO

USE Veterinaria;
GO

CREATE TABLE Usuarios (
    IdUsuario INT PRIMARY KEY IDENTITY,
    NombreUsuario VARCHAR(50),
    Clave VARCHAR(50),
    Rol VARCHAR(20)
);

INSERT INTO Usuarios (NombreUsuario, Clave, Rol)
VALUES 
('Admin', '123', 'Administrador'),
('Cliente', '123', 'Cliente');

CREATE TABLE Agendamientos (
    IdAgendamiento INT PRIMARY KEY IDENTITY,
    NombreDueno VARCHAR(100),
    Telefono VARCHAR(15),
    Correo VARCHAR(100),
    NombreMascota VARCHAR(100),
    TipoMascota VARCHAR(50),
    EdadMascota INT,
    FechaAtencion DATE,
    HoraAtencion TIME,
    MotivoConsulta VARCHAR(255),
    Estado VARCHAR(20) DEFAULT 'Pendiente'
);