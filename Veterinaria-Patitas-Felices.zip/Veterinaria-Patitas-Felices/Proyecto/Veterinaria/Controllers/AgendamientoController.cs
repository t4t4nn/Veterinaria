﻿using System.Collections.Generic;
using Veterinaria.Models;

namespace Veterinaria.Controllers
{
    public class AgendamientoController
    {
        private AgendamientoData _data = new AgendamientoData();

        public List<Agendamiento> ListarAgendamientos()
        {
            return _data.ObtenerAgendamientos();
        }

        public bool Insertar(Agendamiento a)
        {
            return _data.InsertarAgendamiento(a);
        }

        public bool Actualizar(Agendamiento a)
        {
            return _data.ActualizarAgendamiento(a);
        }

        public bool Eliminar(int id)
        {
            return _data.EliminarAgendamiento(id);
        }
    }
}