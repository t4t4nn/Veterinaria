﻿namespace Veterinaria.Views
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFiltrar = new System.Windows.Forms.Label();
            this.cmbFiltroEstado = new System.Windows.Forms.ComboBox();
            this.btnFiltrarEstado = new System.Windows.Forms.Button();
            this.dgvAgendamientos = new System.Windows.Forms.DataGridView();
            this.lblNombreDueno = new System.Windows.Forms.Label();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.lblNombreMascota = new System.Windows.Forms.Label();
            this.lblTipoDeMascota = new System.Windows.Forms.Label();
            this.lblEdadMascota = new System.Windows.Forms.Label();
            this.lblMotivoConsulta = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.lblHoraAtencion = new System.Windows.Forms.Label();
            this.lblFechaAtencion = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.dtpHora = new System.Windows.Forms.DateTimePicker();
            this.cmbEstado = new System.Windows.Forms.ComboBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.txtNombreDueno = new System.Windows.Forms.TextBox();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.txtNombreMascota = new System.Windows.Forms.TextBox();
            this.txtTipoMascota = new System.Windows.Forms.TextBox();
            this.txtEdadMascota = new System.Windows.Forms.TextBox();
            this.txtMotivoConsulta = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgendamientos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFiltrar
            // 
            this.lblFiltrar.AutoSize = true;
            this.lblFiltrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFiltrar.Location = new System.Drawing.Point(715, 71);
            this.lblFiltrar.Name = "lblFiltrar";
            this.lblFiltrar.Size = new System.Drawing.Size(163, 25);
            this.lblFiltrar.TabIndex = 0;
            this.lblFiltrar.Text = "Filtrar por estado:";
            // 
            // cmbFiltroEstado
            // 
            this.cmbFiltroEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFiltroEstado.FormattingEnabled = true;
            this.cmbFiltroEstado.Location = new System.Drawing.Point(923, 74);
            this.cmbFiltroEstado.Name = "cmbFiltroEstado";
            this.cmbFiltroEstado.Size = new System.Drawing.Size(182, 24);
            this.cmbFiltroEstado.TabIndex = 1;
            // 
            // btnFiltrarEstado
            // 
            this.btnFiltrarEstado.Location = new System.Drawing.Point(1164, 74);
            this.btnFiltrarEstado.Name = "btnFiltrarEstado";
            this.btnFiltrarEstado.Size = new System.Drawing.Size(81, 24);
            this.btnFiltrarEstado.TabIndex = 2;
            this.btnFiltrarEstado.Text = "Filtrar";
            this.btnFiltrarEstado.UseVisualStyleBackColor = true;
            this.btnFiltrarEstado.Click += new System.EventHandler(this.btnFiltrar_Click);
            // 
            // dgvAgendamientos
            // 
            this.dgvAgendamientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAgendamientos.Location = new System.Drawing.Point(663, 150);
            this.dgvAgendamientos.Name = "dgvAgendamientos";
            this.dgvAgendamientos.RowHeadersWidth = 51;
            this.dgvAgendamientos.RowTemplate.Height = 24;
            this.dgvAgendamientos.Size = new System.Drawing.Size(652, 411);
            this.dgvAgendamientos.TabIndex = 3;
            this.dgvAgendamientos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvAgendamientos_CellClick);
            // 
            // lblNombreDueno
            // 
            this.lblNombreDueno.AutoSize = true;
            this.lblNombreDueno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreDueno.Location = new System.Drawing.Point(105, 211);
            this.lblNombreDueno.Name = "lblNombreDueno";
            this.lblNombreDueno.Size = new System.Drawing.Size(150, 25);
            this.lblNombreDueno.TabIndex = 4;
            this.lblNombreDueno.Text = "Nombre Dueño:";
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefono.Location = new System.Drawing.Point(105, 261);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(95, 25);
            this.lblTelefono.TabIndex = 5;
            this.lblTelefono.Text = "Teléfono:";
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCorreo.Location = new System.Drawing.Point(105, 312);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(72, 25);
            this.lblCorreo.TabIndex = 6;
            this.lblCorreo.Text = "Correo";
            // 
            // lblNombreMascota
            // 
            this.lblNombreMascota.AutoSize = true;
            this.lblNombreMascota.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombreMascota.Location = new System.Drawing.Point(105, 363);
            this.lblNombreMascota.Name = "lblNombreMascota";
            this.lblNombreMascota.Size = new System.Drawing.Size(194, 25);
            this.lblNombreMascota.TabIndex = 7;
            this.lblNombreMascota.Text = "Nombre de Mascota:";
            // 
            // lblTipoDeMascota
            // 
            this.lblTipoDeMascota.AutoSize = true;
            this.lblTipoDeMascota.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoDeMascota.Location = new System.Drawing.Point(105, 414);
            this.lblTipoDeMascota.Name = "lblTipoDeMascota";
            this.lblTipoDeMascota.Size = new System.Drawing.Size(164, 25);
            this.lblTipoDeMascota.TabIndex = 8;
            this.lblTipoDeMascota.Text = "Tipo de Mascota:";
            // 
            // lblEdadMascota
            // 
            this.lblEdadMascota.AutoSize = true;
            this.lblEdadMascota.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEdadMascota.Location = new System.Drawing.Point(105, 464);
            this.lblEdadMascota.Name = "lblEdadMascota";
            this.lblEdadMascota.Size = new System.Drawing.Size(144, 25);
            this.lblEdadMascota.TabIndex = 9;
            this.lblEdadMascota.Text = "Edad Mascota:";
            // 
            // lblMotivoConsulta
            // 
            this.lblMotivoConsulta.AutoSize = true;
            this.lblMotivoConsulta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMotivoConsulta.Location = new System.Drawing.Point(105, 509);
            this.lblMotivoConsulta.Name = "lblMotivoConsulta";
            this.lblMotivoConsulta.Size = new System.Drawing.Size(159, 25);
            this.lblMotivoConsulta.TabIndex = 10;
            this.lblMotivoConsulta.Text = "Motivo Consulta:";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstado.Location = new System.Drawing.Point(105, 636);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(79, 25);
            this.lblEstado.TabIndex = 12;
            this.lblEstado.Text = "Estado:";
            // 
            // lblHoraAtencion
            // 
            this.lblHoraAtencion.AutoSize = true;
            this.lblHoraAtencion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoraAtencion.Location = new System.Drawing.Point(105, 597);
            this.lblHoraAtencion.Name = "lblHoraAtencion";
            this.lblHoraAtencion.Size = new System.Drawing.Size(142, 25);
            this.lblHoraAtencion.TabIndex = 15;
            this.lblHoraAtencion.Text = "Hora Atención:";
            // 
            // lblFechaAtencion
            // 
            this.lblFechaAtencion.AutoSize = true;
            this.lblFechaAtencion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaAtencion.Location = new System.Drawing.Point(105, 559);
            this.lblFechaAtencion.Name = "lblFechaAtencion";
            this.lblFechaAtencion.Size = new System.Drawing.Size(155, 25);
            this.lblFechaAtencion.TabIndex = 17;
            this.lblFechaAtencion.Text = "Fecha Atención:";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFecha.Location = new System.Drawing.Point(320, 561);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(211, 22);
            this.dtpFecha.TabIndex = 24;
            // 
            // dtpHora
            // 
            this.dtpHora.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpHora.Location = new System.Drawing.Point(320, 600);
            this.dtpHora.Name = "dtpHora";
            this.dtpHora.ShowUpDown = true;
            this.dtpHora.Size = new System.Drawing.Size(211, 22);
            this.dtpHora.TabIndex = 25;
            // 
            // cmbEstado
            // 
            this.cmbEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstado.FormattingEnabled = true;
            this.cmbEstado.Location = new System.Drawing.Point(320, 640);
            this.cmbEstado.Name = "cmbEstado";
            this.cmbEstado.Size = new System.Drawing.Size(211, 24);
            this.cmbEstado.TabIndex = 26;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(777, 645);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(88, 30);
            this.btnAgregar.TabIndex = 27;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(897, 645);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(81, 30);
            this.btnActualizar.TabIndex = 28;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(1013, 645);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(81, 30);
            this.btnEliminar.TabIndex = 29;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.Location = new System.Drawing.Point(946, 716);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(112, 30);
            this.btnCerrarSesion.TabIndex = 30;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.UseVisualStyleBackColor = true;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(1129, 645);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(75, 30);
            this.btnNuevo.TabIndex = 31;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(155, 64);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(322, 32);
            this.lblTitulo.TabIndex = 32;
            this.lblTitulo.Text = "Panel de Administración";
            // 
            // txtNombreDueno
            // 
            this.txtNombreDueno.Location = new System.Drawing.Point(320, 211);
            this.txtNombreDueno.Name = "txtNombreDueno";
            this.txtNombreDueno.Size = new System.Drawing.Size(211, 22);
            this.txtNombreDueno.TabIndex = 33;
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(320, 257);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(211, 22);
            this.txtTelefono.TabIndex = 34;
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(320, 312);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(211, 22);
            this.txtCorreo.TabIndex = 35;
            // 
            // txtNombreMascota
            // 
            this.txtNombreMascota.Location = new System.Drawing.Point(320, 363);
            this.txtNombreMascota.Name = "txtNombreMascota";
            this.txtNombreMascota.Size = new System.Drawing.Size(211, 22);
            this.txtNombreMascota.TabIndex = 36;
            // 
            // txtTipoMascota
            // 
            this.txtTipoMascota.Location = new System.Drawing.Point(320, 414);
            this.txtTipoMascota.Name = "txtTipoMascota";
            this.txtTipoMascota.Size = new System.Drawing.Size(211, 22);
            this.txtTipoMascota.TabIndex = 37;
            // 
            // txtEdadMascota
            // 
            this.txtEdadMascota.Location = new System.Drawing.Point(320, 460);
            this.txtEdadMascota.Name = "txtEdadMascota";
            this.txtEdadMascota.Size = new System.Drawing.Size(211, 22);
            this.txtEdadMascota.TabIndex = 38;
            // 
            // txtMotivoConsulta
            // 
            this.txtMotivoConsulta.Location = new System.Drawing.Point(320, 509);
            this.txtMotivoConsulta.Name = "txtMotivoConsulta";
            this.txtMotivoConsulta.Size = new System.Drawing.Size(211, 22);
            this.txtMotivoConsulta.TabIndex = 39;
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1341, 804);
            this.Controls.Add(this.txtMotivoConsulta);
            this.Controls.Add(this.txtEdadMascota);
            this.Controls.Add(this.txtTipoMascota);
            this.Controls.Add(this.txtNombreMascota);
            this.Controls.Add(this.txtCorreo);
            this.Controls.Add(this.txtTelefono);
            this.Controls.Add(this.txtNombreDueno);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnNuevo);
            this.Controls.Add(this.btnCerrarSesion);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.cmbEstado);
            this.Controls.Add(this.dtpHora);
            this.Controls.Add(this.dtpFecha);
            this.Controls.Add(this.lblFechaAtencion);
            this.Controls.Add(this.lblHoraAtencion);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblMotivoConsulta);
            this.Controls.Add(this.lblEdadMascota);
            this.Controls.Add(this.lblTipoDeMascota);
            this.Controls.Add(this.lblNombreMascota);
            this.Controls.Add(this.lblCorreo);
            this.Controls.Add(this.lblTelefono);
            this.Controls.Add(this.lblNombreDueno);
            this.Controls.Add(this.dgvAgendamientos);
            this.Controls.Add(this.btnFiltrarEstado);
            this.Controls.Add(this.cmbFiltroEstado);
            this.Controls.Add(this.lblFiltrar);
            this.Name = "FormAdmin";
            this.Text = "FormAdmin";
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAgendamientos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFiltrar;
        private System.Windows.Forms.ComboBox cmbFiltroEstado;
        private System.Windows.Forms.Button btnFiltrarEstado;
        private System.Windows.Forms.DataGridView dgvAgendamientos;
        private System.Windows.Forms.Label lblNombreDueno;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblCorreo;
        private System.Windows.Forms.Label lblNombreMascota;
        private System.Windows.Forms.Label lblTipoDeMascota;
        private System.Windows.Forms.Label lblEdadMascota;
        private System.Windows.Forms.Label lblMotivoConsulta;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.Label lblHoraAtencion;
        private System.Windows.Forms.Label lblFechaAtencion;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.DateTimePicker dtpHora;
        private System.Windows.Forms.ComboBox cmbEstado;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox txtNombreDueno;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.TextBox txtNombreMascota;
        private System.Windows.Forms.TextBox txtTipoMascota;
        private System.Windows.Forms.TextBox txtEdadMascota;
        private System.Windows.Forms.TextBox txtMotivoConsulta;
    }
}