﻿using System;
using System.Windows.Forms;
using Veterinaria.Controllers;
using Veterinaria.Models;

namespace Veterinaria.Views
{
    public partial class FormAdmin : Form
    {
        private AgendamientoController _controller = new AgendamientoController();
        private int _idSeleccionado = 0;

        public FormAdmin()
        {
            InitializeComponent();
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {
            // Cargar opciones del filtro
            cmbFiltroEstado.Items.Add("Todos");
            cmbFiltroEstado.Items.Add("Pendiente");
            cmbFiltroEstado.Items.Add("Confirmada");
            cmbFiltroEstado.Items.Add("Atendida");
            cmbFiltroEstado.Items.Add("Cancelada");
            cmbFiltroEstado.SelectedIndex = 0;

            // Cargar opciones del estado
            cmbEstado.Items.Add("Pendiente");
            cmbEstado.Items.Add("Confirmada");
            cmbEstado.Items.Add("Atendida");
            cmbEstado.Items.Add("Cancelada");
            cmbEstado.SelectedIndex = 0;

            CargarGrilla();
        }

        private void CargarGrilla()
        {
            try
            {
                dgvAgendamientos.DataSource = _controller.ListarAgendamientos();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar datos: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            string filtro = cmbFiltroEstado.SelectedItem.ToString();

            if (filtro == "Todos")
            {
                CargarGrilla();
                return;
            }

            var lista = _controller.ListarAgendamientos();
            var filtrado = lista.FindAll(a => a.Estado == filtro);
            dgvAgendamientos.DataSource = filtrado;
        }

        private void dgvAgendamientos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow fila = dgvAgendamientos.Rows[e.RowIndex];

                _idSeleccionado = Convert.ToInt32(fila.Cells["IdAgendamiento"].Value);
                txtNombreDueno.Text = fila.Cells["NombreDueno"].Value.ToString();
                txtTelefono.Text = fila.Cells["Telefono"].Value.ToString();
                txtCorreo.Text = fila.Cells["Correo"].Value.ToString();
                txtNombreMascota.Text = fila.Cells["NombreMascota"].Value.ToString();
                txtTipoMascota.Text = fila.Cells["TipoMascota"].Value.ToString();
                txtEdadMascota.Text = fila.Cells["EdadMascota"].Value.ToString();
                dtpFecha.Value = Convert.ToDateTime(fila.Cells["FechaAtencion"].Value);
                txtMotivoConsulta.Text = fila.Cells["MotivoConsulta"].Value.ToString();
                cmbEstado.SelectedItem = fila.Cells["Estado"].Value.ToString();
            }
        }

        private bool ValidarCampos()
        {
            if (txtNombreDueno.Text == "" || txtTelefono.Text == "" ||
                txtCorreo.Text == "" || txtNombreMascota.Text == "" ||
                txtTipoMascota.Text == "" || txtEdadMascota.Text == "" ||
                txtMotivoConsulta.Text == "")
            {
                MessageBox.Show("Complete todos los campos", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!int.TryParse(txtEdadMascota.Text, out _))
            {
                MessageBox.Show("La edad debe ser un número", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(txtTelefono.Text, @"^\d+$"))
            {
                MessageBox.Show("El teléfono solo debe contener números", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (dtpFecha.Value.Date < DateTime.Today)
            {
                MessageBox.Show("La fecha de atención no puede ser anterior a hoy", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (dtpFecha.Value.Date == DateTime.Today && dtpHora.Value.TimeOfDay < DateTime.Now.TimeOfDay)
            {
                MessageBox.Show("La hora de atención no puede ser anterior a la hora actual", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }

        private Agendamiento ObtenerDatosFormulario()
        {
            return new Agendamiento()
            {
                IdAgendamiento = _idSeleccionado,
                NombreDueno = txtNombreDueno.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text,
                NombreMascota = txtNombreMascota.Text,
                TipoMascota = txtTipoMascota.Text,
                EdadMascota = int.Parse(txtEdadMascota.Text),
                FechaAtencion = dtpFecha.Value.ToString("yyyy-MM-dd"),
                HoraAtencion = dtpHora.Value.ToString("HH:mm"),
                MotivoConsulta = txtMotivoConsulta.Text,
                Estado = cmbEstado.SelectedIndex >= 0 ? cmbEstado.SelectedItem.ToString() : "Pendiente"
            };
        }

        private void LimpiarCampos()
        {
            _idSeleccionado = 0;
            txtNombreDueno.Text = "";
            txtTelefono.Text = "";
            txtCorreo.Text = "";
            txtNombreMascota.Text = "";
            txtTipoMascota.Text = "";
            txtEdadMascota.Text = "";
            txtMotivoConsulta.Text = "";
            dtpFecha.Value = DateTime.Today;
            cmbEstado.SelectedIndex = 0;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if (_idSeleccionado != 0)
            {
                MessageBox.Show("Para agregar un nuevo registro, primero presione 'Nuevo' para limpiar los campos.",
                    "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidarCampos()) return;

            var agendamiento = ObtenerDatosFormulario();

            if (_controller.Insertar(agendamiento))
            {
                MessageBox.Show("Agendamiento agregado correctamente", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarCampos();
                CargarGrilla();
            }
            else
            {
                MessageBox.Show("Error al agregar", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            if (_idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un agendamiento de la tabla", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!ValidarCampos()) return;

            var agendamiento = ObtenerDatosFormulario();

            if (_controller.Actualizar(agendamiento))
            {
                MessageBox.Show("Agendamiento actualizado correctamente", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarCampos();
                CargarGrilla();
            }
            else
            {
                MessageBox.Show("Error al actualizar", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (_idSeleccionado == 0)
            {
                MessageBox.Show("Seleccione un agendamiento de la tabla", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult resultado = MessageBox.Show(
                "¿Seguro que deseas eliminar este agendamiento?",
                "Confirmar",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.Yes)
            {
                if (_controller.Eliminar(_idSeleccionado))
                {
                    MessageBox.Show("Agendamiento eliminado", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimpiarCampos();
                    CargarGrilla();
                }
                else
                {
                    MessageBox.Show("Error al eliminar", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show(
                "¿Seguro que deseas cerrar sesión?",
                "Cerrar sesión",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.Yes)
            {
                LoginForm login = new LoginForm();
                login.Show();
                this.Close();
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }


    }
}