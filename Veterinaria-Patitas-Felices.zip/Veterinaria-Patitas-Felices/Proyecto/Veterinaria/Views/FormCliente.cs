﻿using System;
using System.Windows.Forms;
using Veterinaria.Models;
using Veterinaria.Controllers;

namespace Veterinaria.Views
{
    public partial class FormCliente : Form
    {
        private AgendamientoController _controller = new AgendamientoController();

        public FormCliente()
        {
            InitializeComponent();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            // Validar campos vacíos
            if (txtNombre.Text == "" || txtTelefono.Text == "" ||
                txtCorreo.Text == "" || txtNombreMascota.Text == "" ||
                txtTipoMascota.Text == "" || txtEdadMascota.Text == "" ||
                txtMotivoConsulta.Text == "")
            {
                MessageBox.Show("Complete todos los campos", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que edad sea número
            if (!int.TryParse(txtEdadMascota.Text, out int edad))
            {
                MessageBox.Show("La edad debe ser un número", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar teléfono (solo números)
            if (!System.Text.RegularExpressions.Regex.IsMatch(txtTelefono.Text, @"^\d+$"))
            {
                MessageBox.Show("El teléfono solo debe contener números", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que la fecha no sea anterior a hoy
            if (dtpFecha.Value.Date < DateTime.Today)
            {
                MessageBox.Show("La fecha de atención no puede ser anterior a hoy", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Validar que si es hoy, la hora no sea anterior a la actual
            if (dtpFecha.Value.Date == DateTime.Today && dtpHora.Value.TimeOfDay < DateTime.Now.TimeOfDay)
            {
                MessageBox.Show("La hora de atención no puede ser anterior a la hora actual", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var agendamiento = new Agendamiento()
            {
                NombreDueno = txtNombre.Text,
                Telefono = txtTelefono.Text,
                Correo = txtCorreo.Text,
                NombreMascota = txtNombreMascota.Text,
                TipoMascota = txtTipoMascota.Text,
                EdadMascota = edad,
                FechaAtencion = dtpFecha.Value.ToString("yyyy-MM-dd"),
                HoraAtencion = dtpHora.Value.ToString("HH:mm"),
                MotivoConsulta = txtMotivoConsulta.Text
            };

            if (_controller.Insertar(agendamiento))
            {
                MessageBox.Show("¡Reserva registrada exitosamente! Estado: Pendiente", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarCampos();
            }
            else
            {
                MessageBox.Show("Error al registrar la reserva", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarCampos()
        {
            txtNombre.Text = "";
            txtTelefono.Text = "";
            txtCorreo.Text = "";
            txtNombreMascota.Text = "";
            txtTipoMascota.Text = "";
            txtEdadMascota.Text = "";
            txtMotivoConsulta.Text = "";
            dtpFecha.Value = DateTime.Today;
            dtpHora.Value = DateTime.Today;
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            DialogResult resultado = MessageBox.Show(
                "¿Seguro que deseas cerrar sesión?",
                "Cerrar sesión",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.Yes)
            {
                LoginForm login = new LoginForm();
                login.Show();
                this.Close();
            }
        }
    }
}