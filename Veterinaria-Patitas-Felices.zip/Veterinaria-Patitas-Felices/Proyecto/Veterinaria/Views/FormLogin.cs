﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Veterinaria.Models;

namespace Veterinaria.Views
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string clave = txtContrasena.Text.Trim();

            if (usuario == "" || clave == "")
            {
                MessageBox.Show("Ingrese usuario y contraseña", "Aviso",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            UsuarioData data = new UsuarioData();
            string rol = data.ValidarUsuario(usuario, clave);

            if (rol == "Administrador")
            {
                FormAdmin form = new FormAdmin();
                form.Show();
                this.Hide();
            }
            else if (rol == "Cliente")
            {
                FormCliente form = new FormCliente();
                form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuario o contraseña incorrectos", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {
            lblTitulo.AutoSize = true;
        }
    }
}