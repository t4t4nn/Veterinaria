﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veterinaria.Models
{
    public class AgendamientoData
    {

        private string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=Veterinaria;Trusted_Connection=True;";
                
        public List<Agendamiento> ObtenerAgendamientos()
        {
            List<Agendamiento> lista = new List<Agendamiento>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Agendamientos";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Agendamiento()
                    {
                        IdAgendamiento = Convert.ToInt32(reader["IdAgendamiento"]),
                        NombreDueno = reader["NombreDueno"].ToString(),
                        Telefono = reader["Telefono"].ToString(),
                        Correo = reader["Correo"].ToString(),
                        NombreMascota = reader["NombreMascota"].ToString(),
                        TipoMascota = reader["TipoMascota"].ToString(),
                        EdadMascota = Convert.ToInt32(reader["EdadMascota"]),
                        FechaAtencion = reader["FechaAtencion"].ToString(),
                        HoraAtencion = reader["HoraAtencion"].ToString(),
                        MotivoConsulta = reader["MotivoConsulta"].ToString(),
                        Estado = reader["Estado"].ToString()
                    });
                }
            }
            return lista;
        }
        
        public bool InsertarAgendamiento(Agendamiento a)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Agendamientos 
                    (NombreDueno, Telefono, Correo, NombreMascota, TipoMascota, 
                     EdadMascota, FechaAtencion, HoraAtencion, MotivoConsulta, Estado)
                    VALUES 
                    (@dueno, @tel, @correo, @mascota, @tipo, 
                     @edad, @fecha, @hora, @motivo, 'Pendiente')";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@dueno", a.NombreDueno);
                cmd.Parameters.AddWithValue("@tel", a.Telefono);
                cmd.Parameters.AddWithValue("@correo", a.Correo);
                cmd.Parameters.AddWithValue("@mascota", a.NombreMascota);
                cmd.Parameters.AddWithValue("@tipo", a.TipoMascota);
                cmd.Parameters.AddWithValue("@edad", a.EdadMascota);
                cmd.Parameters.AddWithValue("@fecha", a.FechaAtencion);
                cmd.Parameters.AddWithValue("@hora", a.HoraAtencion);
                cmd.Parameters.AddWithValue("@motivo", a.MotivoConsulta);

                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool ActualizarAgendamiento(Agendamiento a)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Agendamientos SET 
                    NombreDueno=@dueno, Telefono=@tel, Correo=@correo,
                    NombreMascota=@mascota, TipoMascota=@tipo, EdadMascota=@edad,
                    FechaAtencion=@fecha, HoraAtencion=@hora, MotivoConsulta=@motivo,
                    Estado=@estado
                    WHERE IdAgendamiento=@id";

                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", a.IdAgendamiento);
                cmd.Parameters.AddWithValue("@dueno", a.NombreDueno);
                cmd.Parameters.AddWithValue("@tel", a.Telefono);
                cmd.Parameters.AddWithValue("@correo", a.Correo);
                cmd.Parameters.AddWithValue("@mascota", a.NombreMascota);
                cmd.Parameters.AddWithValue("@tipo", a.TipoMascota);
                cmd.Parameters.AddWithValue("@edad", a.EdadMascota);
                cmd.Parameters.AddWithValue("@fecha", a.FechaAtencion);
                cmd.Parameters.AddWithValue("@hora", a.HoraAtencion);
                cmd.Parameters.AddWithValue("@motivo", a.MotivoConsulta);
                cmd.Parameters.AddWithValue("@estado", a.Estado);

                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool EliminarAgendamiento(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Agendamientos WHERE IdAgendamiento=@id";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                return cmd.ExecuteNonQuery() > 0;
            }
        }
    

    }
}
