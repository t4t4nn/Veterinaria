﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Veterinaria.Models
{
    public class UsuarioData
    {

        private string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=Veterinaria;Trusted_Connection=True;";

        public string ValidarUsuario(string usuario, string clave)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT Rol FROM Usuarios WHERE NombreUsuario=@user AND Clave=@pass";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@user", usuario);
                cmd.Parameters.AddWithValue("@pass", clave);

                con.Open();

                var resultado = cmd.ExecuteScalar();

                if (resultado != null)
                    return resultado.ToString();
                else
                    return null;
            }
        }

    }
}
